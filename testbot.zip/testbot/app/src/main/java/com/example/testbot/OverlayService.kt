package com.example.testbot

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.*
import kotlin.random.Random

class OverlayService : Service() {
    // ---- общие настройки точности (для всех игр) ----
    private val leadMs = 80f        // упреждение по движущейся цели
    private val jitterPx = 10       // разброс тапа
    private val missChance = 0.10f  // шанс «специально промахнуться»
    private val minGapMs = 250L     // пауза между тапами (режим ТАП)
    private val scale = 0.4f        // уменьшение кадра для анализа

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var preview: ImageView
    private lateinit var logTv: TextView
    private val main = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("bot").apply { start() }
    private val bg = Handler(worker.looper)

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var cw = 0
    private var ch = 0
    private val hsv = FloatArray(3)

    private lateinit var profiles: MutableList<Profile>
    @Volatile private var cur = 0
    private val prof get() = profiles[cur]
    @Volatile private var botOn = false
    @Volatile private var lastFrame: Bitmap? = null
    @Volatile private var hidden = false
    private lateinit var bubble: ImageView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var calib = 0
    private val calibNames = arrayOf("Цель", "Угроза", "Игрок", "Стик движения", "Стик прицела", "Кнопка огня")

    private var lastX = 0f; private var lastY = 0f; private var lastT = 0L; private var lastTap = 0L
    private var frame = 0

    class Blob(val x: Float, val y: Float, val n: Int)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "SHOW" -> { if (::root.isInitialized) showWindow(); return START_NOT_STICKY }
            "STOP" -> { stopSelf(); return START_NOT_STICKY }
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(
            this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "bot").setContentTitle("Test Bot работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(0, "Показать окно", pi("SHOW")).build())
            .addAction(Notification.Action.Builder(0, "Выключить", pi("STOP")).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(i?.getIntExtra("code", 0) ?: 0, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, bg)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        profiles = Profile.loadAll(this)
        buildOverlay()
        setupCapture()
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density)
    private fun dpi(v: Int) = dp(v).toInt()

    private fun setupCapture() {
        val b = wm.maximumWindowMetrics.bounds
        cw = (b.width() * scale).toInt(); ch = (b.height() * scale).toInt()
        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay(
            "cap", cw, ch, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        reader!!.setOnImageAvailableListener({ process(it) }, bg)
    }

    // ---------- поиск объектов по цвету ----------
    private fun hueDist(a: Float, b: Float): Float { val d = abs(a - b); return min(d, 360 - d) }

    private fun blobs(px: IntArray, bw: Int, hue: Float, tol: Float, ov: Rect): List<Blob> {
        if (hue < 0) return emptyList()
        val cell = 6
        val gw = (cw + cell - 1) / cell; val gh = (ch + cell - 1) / cell
        val cnt = IntArray(gw * gh); val sx = FloatArray(gw * gh); val sy = FloatArray(gw * gh)
        for (y in 0 until ch step 2) for (x in 0 until cw step 2) {
            if (ov.contains(x, y)) continue
            Color.colorToHSV(px[y * bw + x], hsv)
            if (hsv[1] > 0.5f && hsv[2] > 0.4f && hueDist(hsv[0], hue) <= tol) {
                val i = (y / cell) * gw + (x / cell); cnt[i]++; sx[i] += x; sy[i] += y
            }
        }
        val seen = BooleanArray(gw * gh); val out = ArrayList<Blob>()
        for (i in cnt.indices) if (cnt[i] >= 2 && !seen[i]) {
            var tn = 0; var tx = 0f; var ty = 0f
            val q = ArrayDeque<Int>(); q.add(i); seen[i] = true
            while (q.isNotEmpty()) {
                val c = q.removeFirst(); tn += cnt[c]; tx += sx[c]; ty += sy[c]
                val cx = c % gw; val cy = c / gw
                for (d in 0..3) {
                    val nx = cx + (if (d == 0) 1 else if (d == 1) -1 else 0)
                    val ny = cy + (if (d == 2) 1 else if (d == 3) -1 else 0)
                    if (nx in 0 until gw && ny in 0 until gh) {
                        val j = ny * gw + nx
                        if (!seen[j] && cnt[j] >= 2) { seen[j] = true; q.add(j) }
                    }
                }
            }
            if (tn >= 4) out.add(Blob(tx / tn, ty / tn, tn))
        }
        return out
    }

    // ---------- главный шаг: каждый кадр ----------
    private fun process(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        val pl = img.planes[0]
        val bw = pl.rowStride / pl.pixelStride
        val bmp = Bitmap.createBitmap(bw, ch, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(pl.buffer)
        img.close()
        val px = IntArray(bw * ch)
        bmp.getPixels(px, 0, bw, 0, 0, bw, ch)

        val p = prof
        val ov = if (hidden) Rect(
            (bubbleLp.x * scale).toInt(), (bubbleLp.y * scale).toInt(),
            ((bubbleLp.x + dpi(48)) * scale).toInt(), ((bubbleLp.y + dpi(48)) * scale).toInt()
        ) else Rect(
            (lp.x * scale).toInt(), (lp.y * scale).toInt(),
            ((lp.x + lp.width) * scale).toInt(), ((lp.y + lp.height) * scale).toInt()
        )
        val targets = blobs(px, bw, p.targetHue, p.tol, ov)
        val threats = blobs(px, bw, p.threatHue, p.tol, ov)
        val player: PointF = blobs(px, bw, p.playerHue, p.tol, ov).maxByOrNull { it.n }
            ?.let { PointF(it.x, it.y) } ?: PointF(cw / 2f, ch / 2f)
        val px0 = player.x / scale; val py0 = player.y / scale   // игрок в пикселях экрана

        var status = "цели ${targets.size}  угрозы ${threats.size}"
        var tgtSeen: Blob? = null
        val stickR = dp(45)

        if (botOn) {
            var moveT: PointF? = null
            // ---- уворот: отталкиваемся от всех близких угроз ----
            if (p.dodge && p.moveX >= 0) {
                val danger = min(cw, ch) * p.dangerFrac
                var vx = 0f; var vy = 0f
                for (t in threats) {
                    val dx = player.x - t.x; val dy = player.y - t.y
                    val d = hypot(dx, dy).coerceAtLeast(1f)
                    if (d < danger) { val w = (danger - d) / danger; vx += dx / d * w; vy += dy / d * w }
                }
                val m = hypot(vx, vy)
                if (m > 0.05f) moveT = PointF(p.moveX + vx / m * stickR, p.moveY + vy / m * stickR)
            }

            // ---- стрельба по ближайшей цели ----
            var tap: PointF? = null; var aimT: PointF? = null; var fire: PointF? = null
            val tgt = targets.minByOrNull { hypot(it.x - player.x, it.y - player.y) }
            if (tgt != null) {
                tgtSeen = tgt
                val sx = tgt.x / scale; val sy = tgt.y / scale
                val now = SystemClock.uptimeMillis()
                var ax = sx; var ay = sy
                if (lastT > 0 && now - lastT in 1..300 && hypot(sx - lastX, sy - lastY) < dp(60)) {
                    val dt = (now - lastT).toFloat()
                    ax += (sx - lastX) / dt * leadMs; ay += (sy - lastY) / dt * leadMs
                }
                lastX = sx; lastY = sy; lastT = now

                if (p.mode == 0) {
                    if (now - lastTap >= minGapMs && Random.nextFloat() > missChance) {
                        lastTap = now
                        tap = PointF(ax + Random.nextInt(-jitterPx, jitterPx + 1), ay + Random.nextInt(-jitterPx, jitterPx + 1))
                    }
                } else if (p.aimX >= 0) {
                    val err = if (Random.nextFloat() < missChance) (Random.nextFloat() - 0.5f) * 0.7f
                              else (Random.nextFloat() - 0.5f) * 0.08f
                    val ang = atan2(ay - py0, ax - px0) + err
                    aimT = PointF(p.aimX + cos(ang) * stickR, p.aimY + sin(ang) * stickR)
                    if (p.fireX >= 0) fire = PointF(p.fireX, p.fireY)
                }
            } else lastT = 0

            val cmd = BotAccessibilityService.Cmd(
                moveC = moveT?.let { PointF(p.moveX, p.moveY) }, moveT = moveT,
                aimC = aimT?.let { PointF(p.aimX, p.aimY) }, aimT = aimT,
                fire = fire, tap = tap
            )
            val svc = BotAccessibilityService.instance
            if (svc == null) status += "  (включи Доступность!)" else svc.submit(cmd)
        }

        if (frame++ % 3 == 0) {
            val show = Bitmap.createBitmap(bmp, 0, 0, cw, ch)
            val c = Canvas(show)
            val pt = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f }
            pt.color = Color.GREEN; targets.forEach { c.drawCircle(it.x, it.y, 18f, pt) }
            pt.color = Color.RED; threats.forEach { c.drawCircle(it.x, it.y, 14f, pt) }
            pt.color = Color.CYAN; c.drawCircle(player.x, player.y, 22f, pt)
            pt.color = Color.YELLOW
            for ((x, y) in listOf(p.moveX to p.moveY, p.aimX to p.aimY, p.fireX to p.fireY))
                if (x >= 0) c.drawCircle(x * scale, y * scale, 20f, pt)
            lastFrame = show
            if (!hidden) main.post { preview.setImageBitmap(show); logTv.text = (if (botOn) "▶ " else "⏸ ") + status }
        }
    }

    // ---------- калибровка тапом по превью ----------
    private fun pickAt(x: Float, y: Float) {
        val f = lastFrame ?: return
        val vw = preview.width.toFloat(); val vh = preview.height.toFloat()
        val s = min(vw / cw, vh / ch)
        val bx = ((x - (vw - cw * s) / 2) / s).toInt(); val by = ((y - (vh - ch * s) / 2) / s).toInt()
        if (bx !in 0 until cw || by !in 0 until ch) return
        val p = prof
        if (calib <= 2) {
            // берём самый яркий насыщенный пиксель рядом с точкой
            var best = -1f; var hue = -1f; val h = FloatArray(3)
            for (dy in -3..3) for (dx in -3..3) {
                val xx = bx + dx; val yy = by + dy
                if (xx !in 0 until cw || yy !in 0 until ch) continue
                Color.colorToHSV(f.getPixel(xx, yy), h)
                if (h[1] * h[2] > best) { best = h[1] * h[2]; hue = h[0] }
            }
            if (best < 0.3f) { toast("Тут нет яркого цвета, ткни точнее в объект"); return }
            when (calib) { 0 -> p.targetHue = hue; 1 -> p.threatHue = hue; else -> p.playerHue = hue }
            toast("${calibNames[calib]}: цвет сохранён")
        } else {
            val sxp = bx / scale; val syp = by / scale
            when (calib) { 3 -> { p.moveX = sxp; p.moveY = syp }; 4 -> { p.aimX = sxp; p.aimY = syp }; else -> { p.fireX = sxp; p.fireY = syp } }
            toast("${calibNames[calib]}: позиция сохранена")
        }
        Profile.saveAll(this, profiles)
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

    // ---------- мини-окно ----------
    private fun btn(text: String, onClick: (Button) -> Unit) = Button(this).apply {
        this.text = text; textSize = 10f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; setPadding(2, 6, 2, 6)
        setOnClickListener { onClick(this) }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (b in v) addView(b, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun buildOverlay() {
        lp = WindowManager.LayoutParams(
            dpi(300), dpi(430), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 10; y = 120 }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE111111.toInt())
            setPadding(dpi(6), dpi(6), dpi(6), dpi(6))
        }

        val title = TextView(this).apply {
            text = "☰  Test Bot  (тяни за заголовок)"; setTextColor(Color.WHITE)
        }
        var dx = 0f; var dy = 0f; var sx0 = 0; var sy0 = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx0 = lp.x; sy0 = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx0 + (e.rawX - dx).toInt(); lp.y = sy0 + (e.rawY - dy).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }; true
        }

        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.BLACK) }
        preview.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_UP) pickAt(e.x, e.y); true }
        logTv = TextView(this).apply { setTextColor(Color.GREEN); textSize = 11f; text = "готов"; maxLines = 2 }

        val bProfile = btn("") {}
        fun refreshProfile() { bProfile.text = "Игра: ${prof.name}" }
        bProfile.setOnClickListener { cur = (cur + 1) % profiles.size; refreshProfile() }
        val bNew = btn("+ Новая игра") {
            profiles.add(Profile("game${profiles.size + 1}")); cur = profiles.size - 1
            Profile.saveAll(this, profiles); refreshProfile()
        }
        refreshProfile()

        val bCal = btn("") {}
        fun refreshCal() { bCal.text = "Задать: ${calibNames[calib]} (тык в превью)" }
        bCal.setOnClickListener { calib = (calib + 1) % calibNames.size; refreshCal() }
        refreshCal()

        val bMode = btn("") {}
        fun refreshMode() { bMode.text = if (prof.mode == 0) "Режим: Тап" else "Режим: Стик+огонь" }
        bMode.setOnClickListener { prof.mode = 1 - prof.mode; Profile.saveAll(this, profiles); refreshMode() }
        val bDodge = btn("") {}
        fun refreshDodge() { bDodge.text = if (prof.dodge) "Уворот: вкл" else "Уворот: выкл" }
        bDodge.setOnClickListener { prof.dodge = !prof.dodge; Profile.saveAll(this, profiles); refreshDodge() }
        refreshMode(); refreshDodge()
        bProfile.setOnClickListener { cur = (cur + 1) % profiles.size; refreshProfile(); refreshMode(); refreshDodge() }

        val bStart = btn("Старт") {}
        bStart.setOnClickListener {
            botOn = !botOn; bStart.text = if (botOn) "Стоп" else "Старт"
            if (!botOn) BotAccessibilityService.instance?.submit(BotAccessibilityService.Cmd())  // отпустить пальцы
        }
        val bBack = btn("Назад") {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val bHide = btn("Скрыть") { hideWindow() }
        val bClose = btn("✕") { toast("Удерживай ✕, чтобы выключить бота") }
        bClose.setOnLongClickListener { stopSelf(); true }

        val handle = TextView(this).apply { text = "◢"; setTextColor(Color.WHITE); gravity = Gravity.END; textSize = 20f }
        var rx = 0f; var ry = 0f; var rw = 0; var rh = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = lp.width; rh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (rw + e.rawX - rx).toInt().coerceAtLeast(dpi(220))
                    lp.height = (rh + e.rawY - ry).toInt().coerceAtLeast(dpi(300))
                    wm.updateViewLayout(root, lp)
                }
            }; true
        }

        root.addView(title)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(logTv)
        root.addView(row(bProfile, bNew))
        root.addView(bCal, LinearLayout.LayoutParams(-1, -2))
        root.addView(row(bMode, bDodge))
        root.addView(row(bStart, bHide, bBack, bClose))
        root.addView(handle, LinearLayout.LayoutParams(-1, -2))
        wm.addView(root, lp)

        // маленький кружок с твоей иконкой: бот продолжает работать, тап по кружку возвращает окно
        bubbleLp = WindowManager.LayoutParams(
            dpi(48), dpi(48), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        bubble = ImageView(this).apply { setImageResource(R.drawable.ic_bot); alpha = 0.6f }
        var bx = 0f; var by = 0f; var bx0 = 0; var by0 = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { bx = e.rawX; by = e.rawY; bx0 = bubbleLp.x; by0 = bubbleLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - bx) + abs(e.rawY - by) > dp(8)) moved = true
                    if (moved) {
                        bubbleLp.x = bx0 + (e.rawX - bx).toInt(); bubbleLp.y = by0 + (e.rawY - by).toInt()
                        wm.updateViewLayout(bubble, bubbleLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) showWindow()
            }; true
        }
    }

    private fun hideWindow() {
        if (hidden) return
        bubbleLp.x = lp.x; bubbleLp.y = lp.y
        hidden = true
        runCatching { wm.removeView(root) }
        runCatching { wm.addView(bubble, bubbleLp) }
    }

    private fun showWindow() {
        if (!hidden) return
        hidden = false
        runCatching { wm.removeView(bubble) }
        runCatching { wm.addView(root, lp) }
    }

    override fun onDestroy() {
        BotAccessibilityService.instance?.submit(BotAccessibilityService.Cmd())
        runCatching { wm.removeView(root) }
        runCatching { wm.removeView(bubble) }
        vd?.release(); reader?.close(); projection?.stop(); worker.quitSafely()
        super.onDestroy()
    }
}
