package com.example.testbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PointF
import android.view.accessibility.AccessibilityEvent

/**
 * Управляет пальцами: одновременно стик движения, стик прицела, кнопка огня и тап.
 * Стики «держатся» непрерывными жестами (continueStroke), поэтому палец не отпускается между кадрами.
 */
class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    /** Команда на один шаг. null = этот палец отпущен. */
    class Cmd(
        val moveC: PointF? = null, val moveT: PointF? = null,   // стик движения: центр -> куда тянуть
        val aimC: PointF? = null, val aimT: PointF? = null,     // стик прицела
        val fire: PointF? = null,                               // удерживать кнопку огня
        val tap: PointF? = null                                 // одиночный тап
    )

    private class Finger { var stroke: GestureDescription.StrokeDescription? = null; var last: PointF? = null }
    private val moveF = Finger(); private val aimF = Finger(); private val fireF = Finger()
    private var busy = false
    private var pending: Cmd? = null
    private val stepMs = 100L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    @Synchronized fun submit(c: Cmd) { pending = c; if (!busy) flush() }

    @Synchronized private fun flush() {
        val c = pending ?: return
        pending = null
        val b = GestureDescription.Builder()
        var n = 0
        if (addFinger(moveF, c.moveC, c.moveT, b)) n++
        if (addFinger(aimF, c.aimC, c.aimT, b)) n++
        val fp = c.fire?.let { PointF(it.x + 1f, it.y) }
        if (addFinger(fireF, c.fire, fp, b)) n++
        c.tap?.let {
            val p = Path().apply { moveTo(it.x, it.y) }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, 40)); n++
        }
        if (n == 0) return
        busy = true
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done() }
            override fun onCancelled(g: GestureDescription?) { resetFingers(); done() }
        }, null)
        if (!ok) { busy = false; resetFingers() }
    }

    @Synchronized private fun done() { busy = false; if (pending != null) flush() }

    private fun resetFingers() {
        for (f in listOf(moveF, aimF, fireF)) { f.stroke = null; f.last = null }
    }

    private fun addFinger(f: Finger, c: PointF?, t: PointF?, b: GestureDescription.Builder): Boolean {
        if (c != null && t != null) {
            val path = Path()
            val prev = f.stroke
            val st = if (prev == null) {
                path.moveTo(c.x, c.y); path.lineTo(t.x, t.y)
                GestureDescription.StrokeDescription(path, 0, stepMs, true)
            } else {
                val l = f.last!!
                path.moveTo(l.x, l.y); path.lineTo(t.x, t.y)
                prev.continueStroke(path, 0, stepMs, true)
            }
            f.stroke = st; f.last = PointF(t.x, t.y)
            b.addStroke(st)
            return true
        }
        val prev = f.stroke ?: return false
        val l = f.last!!
        val path = Path().apply { moveTo(l.x, l.y) }
        b.addStroke(prev.continueStroke(path, 0, 1, false))   // отпускаем палец
        f.stroke = null; f.last = null
        return true
    }
}
