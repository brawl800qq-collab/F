package com.example.testbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#111111"))
            setPadding(48, 96, 48, 48)
        }
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_bot)
            layoutParams = LinearLayout.LayoutParams(360, 360)
        })
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        btn("1. Разрешить поверх окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Включить Доступность (Test Bot taps)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Запустить бота") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            } else {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
            }
        }
        setContentView(col)
    }

    @Deprecated("simple demo")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            )
        }
    }
}
