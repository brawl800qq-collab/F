package com.example.testbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Профиль = настройки под одну игру. Все координаты — в пикселях реального экрана. */
class Profile(var name: String) {
    var mode = 0              // 0 = ТАП по цели, 1 = СТИК (стик прицела + кнопка огня)
    var dodge = false         // уворачиваться от угроз стиком движения
    var targetHue = -1f       // цвет цели (Hue 0..360), -1 = не задан
    var threatHue = -1f       // цвет угроз (пули/враги)
    var playerHue = -1f       // цвет игрока; -1 = игрок считается в центре экрана
    var moveX = -1f; var moveY = -1f   // центр стика движения
    var aimX = -1f; var aimY = -1f     // центр стика прицела
    var fireX = -1f; var fireY = -1f   // кнопка огня
    var tol = 22f             // допуск по цвету
    var dangerFrac = 0.30f    // радиус опасности (доля меньшей стороны экрана)

    fun toJson() = JSONObject().apply {
        put("name", name); put("mode", mode); put("dodge", dodge)
        put("targetHue", targetHue.toDouble()); put("threatHue", threatHue.toDouble())
        put("playerHue", playerHue.toDouble())
        put("moveX", moveX.toDouble()); put("moveY", moveY.toDouble())
        put("aimX", aimX.toDouble()); put("aimY", aimY.toDouble())
        put("fireX", fireX.toDouble()); put("fireY", fireY.toDouble())
        put("tol", tol.toDouble()); put("dangerFrac", dangerFrac.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject) = Profile(o.getString("name")).apply {
            mode = o.optInt("mode", 0); dodge = o.optBoolean("dodge", false)
            targetHue = o.optDouble("targetHue", -1.0).toFloat()
            threatHue = o.optDouble("threatHue", -1.0).toFloat()
            playerHue = o.optDouble("playerHue", -1.0).toFloat()
            moveX = o.optDouble("moveX", -1.0).toFloat(); moveY = o.optDouble("moveY", -1.0).toFloat()
            aimX = o.optDouble("aimX", -1.0).toFloat(); aimY = o.optDouble("aimY", -1.0).toFloat()
            fireX = o.optDouble("fireX", -1.0).toFloat(); fireY = o.optDouble("fireY", -1.0).toFloat()
            tol = o.optDouble("tol", 22.0).toFloat()
            dangerFrac = o.optDouble("dangerFrac", 0.30).toFloat()
        }

        fun loadAll(ctx: Context): MutableList<Profile> {
            val s = ctx.getSharedPreferences("bot", 0).getString("profiles", null)
            val list = mutableListOf<Profile>()
            if (s != null) runCatching {
                val a = JSONArray(s)
                for (i in 0 until a.length()) list.add(fromJson(a.getJSONObject(i)))
            }
            if (list.isEmpty()) list.add(Profile("game1"))
            return list
        }

        fun saveAll(ctx: Context, list: List<Profile>) {
            val a = JSONArray(); list.forEach { a.put(it.toJson()) }
            ctx.getSharedPreferences("bot", 0).edit().putString("profiles", a.toString()).apply()
        }
    }
}
